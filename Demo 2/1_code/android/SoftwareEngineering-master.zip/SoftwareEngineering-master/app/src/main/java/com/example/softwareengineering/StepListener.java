package com.example.softwareengineering;

/**
 * Created by aymoo on 12/3/2017.
 */

public interface StepListener {
    public  void step(long timeNs);
}
