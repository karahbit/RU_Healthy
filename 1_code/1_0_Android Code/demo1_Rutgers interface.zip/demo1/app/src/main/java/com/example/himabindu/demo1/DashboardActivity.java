package com.example.himabindu.demo1;

/**
 * Created by HIMABINDU on 10/27/2017.
 */

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import static com.example.himabindu.demo1.MainActivity.UserEmail;

public class DashboardActivity extends AppCompatActivity {

    String EmailHolder;
    TextView Email;
    Button LogOUT,Profile, HRM, Step ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Email = (TextView)findViewById(R.id.textView1);
        LogOUT = (Button)findViewById(R.id.button1);
        Profile = (Button)findViewById(R.id.button2);
        HRM = (Button)findViewById(R.id.button3);
        Step = (Button)findViewById(R.id.button4);

        Intent intent = getIntent();

        // Receiving User Email Send By MainActivity.
        EmailHolder = intent.getStringExtra(UserEmail);

        // Setting up received email to TextView.
        Email.setText(Email.getText().toString()+ EmailHolder);

        // Adding click listener to Log Out button.
        LogOUT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Finishing current DashBoard activity on button click.
                finish();

                Toast.makeText(DashboardActivity.this,"Log Out Successful", Toast.LENGTH_LONG).show();

            }
        });

        //Adding click listener to Profile button.
        Profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Opening new user profile activity using intent on button click.
                Intent intent = new Intent(DashboardActivity.this, ProfileActivity.class);
                intent.putExtra(UserEmail, EmailHolder);
                startActivity(intent);
            }
        });

        //Adding click listener to HRM button.
        HRM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Opening new user profile activity using intent on button click.
                Intent intent = new Intent(DashboardActivity.this, HeartRateMonitor.class);
                intent.putExtra(UserEmail, EmailHolder);
                startActivity(intent);
            }
        });


        //Adding click listener to Step counter button.
        Step.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Opening new user profile activity using intent on button click.
                Intent intent = new Intent(DashboardActivity.this, StepCounter.class);
                intent.putExtra(UserEmail, EmailHolder);
                startActivity(intent);
            }
        });
    }
}
