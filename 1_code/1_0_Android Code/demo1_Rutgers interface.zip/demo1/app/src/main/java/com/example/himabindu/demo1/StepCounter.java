package com.example.himabindu.demo1;

/**
 * Created by HIMABINDU on 10/29/2017.
 */

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

public class StepCounter extends AppCompatActivity implements SensorEventListener,StepListener {

    private TextView TvMiles;
    private TextView TvSteps;
    private TextView TvCalories;



    private  StepDetector simpleStepDetector;
    private SensorManager sensorManager;
    private Sensor accel;
    private static final String TEXT_NUM_STEPS = "STEP ";
    private static final String TEXT_Miles_STEPS = "MILE ";
    private static final String TEXT_Miles_Calorie = "CALORIES PER MILE ";

    private double numSteps;
    private double miles;
    private double calories;

    //Intent intent = getIntent();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.step_count);

        //Get Sensor Values using the SensorManager
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        simpleStepDetector = new StepDetector();
        simpleStepDetector.registerListener(this);



        TvSteps=(TextView)findViewById(R.id.tv_steps);
        TvMiles=(TextView) findViewById(R.id.tv_miles);
        TvCalories=(TextView) findViewById(R.id.tv_calories);



        Button BtnStart = (Button) findViewById(R.id.btn_start);
        Button BtnStop = (Button) findViewById(R.id.btn_stop);


        BtnStart.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                numSteps=0;
                sensorManager.registerListener(StepCounter.this, accel, SensorManager.SENSOR_DELAY_FASTEST);


            }
        });
        BtnStop.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                sensorManager.unregisterListener(StepCounter.this);
            }
        });
    }






    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            simpleStepDetector.updateAccel(
                    event.timestamp, event.values[0], event.values[1], event.values[2]);
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void step(long timeNs) {

        numSteps++;
        miles=numSteps*0.0005;
        calories=miles*0.0128;
        DecimalFormat df = new DecimalFormat("#.#####");

        TvSteps.setText(TEXT_NUM_STEPS + numSteps);
        TvMiles.setText(TEXT_Miles_STEPS+(df.format(miles)));
        TvCalories.setText(TEXT_Miles_Calorie+(df.format(calories)));

        //return numSteps;

    }




}
