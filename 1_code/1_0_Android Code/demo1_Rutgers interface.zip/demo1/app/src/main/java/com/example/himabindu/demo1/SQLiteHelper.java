package com.example.himabindu.demo1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by HIMABINDU on 10/27/2017.
 */

public class SQLiteHelper extends SQLiteOpenHelper {

    static String DATABASE_NAME="UserDataBase";

    public static final String TABLE_NAME="usertable";

    //public static final String Table_Column_ID="id";

    public static final String Table_Column_1_Name="name";

    public static final String Table_Column_2_Email="email";

    public static final String Table_Column_3_Password="password";

    public static final String Table_Column_4_Age="age";

    public static final String Table_Column_5_Gender="gender";

    public static final String Table_Column_6_Height="height";

    public static final String Table_Column_7_Weight="weight";

    public static final String Table_Column_8_Target="target";




    public SQLiteHelper(Context context) {

        super(context, DATABASE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase database) {

        String CREATE_TABLE="CREATE TABLE IF NOT EXISTS "+TABLE_NAME+" ("+Table_Column_1_Name+" VARCHAR, "+Table_Column_2_Email+" VARCHAR, "
                +Table_Column_3_Password+" VARCHAR, " + Table_Column_4_Age + "INT, " + Table_Column_5_Gender + "VARCHAR, " + Table_Column_6_Height + "INT, "
                + Table_Column_7_Weight + "INT, " + Table_Column_8_Target + "INT )";
        database.execSQL(CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);

    }
}
