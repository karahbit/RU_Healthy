package com.example.himabindu.demo1;

/**
 * Created by aymoo on 9/19/2017.
 */

public interface StepListener {

    public  void step(long timeNs);

}

